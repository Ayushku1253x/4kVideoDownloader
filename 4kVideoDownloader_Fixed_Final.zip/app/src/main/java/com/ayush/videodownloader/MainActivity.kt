package com.ayush.videodownloader

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val GITHUB_REPO = "Ayushku1253x/4kVideoDownloader" 

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initEngines()
    }

    private fun initEngines() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                YoutubeDL.getInstance().init(application)
                com.yausername.aria2c.Aria2c.getInstance().init(application)
                com.yausername.ffmpeg.FFmpeg.getInstance().init(application)
                YoutubeDL.getInstance().updateYoutubeDL(application, YoutubeDL.UpdateChannel.STABLE)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
